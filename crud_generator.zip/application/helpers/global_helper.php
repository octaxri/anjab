<?php  if ( ! defined("BASEPATH")) exit("No direct script access allowed");
	function generate_sidemenu()
	{
		return '<li>
		<a href="'.site_url('golongans').'"><i class="fa fa-list fa-fw"></i> Golongans</a>
	</li><li>
		<a href="'.site_url('homes').'"><i class="fa fa-list fa-fw"></i> Homes</a>
	</li><li>
		<a href="'.site_url('jabatan_fungsional_angka_kredit').'"><i class="fa fa-list fa-fw"></i> Jabatan fungsional angka kredit</a>
	</li><li>
		<a href="'.site_url('jabatan_fungsional_angka_kredit_minimal').'"><i class="fa fa-list fa-fw"></i> Jabatan fungsional angka kredit minimal</a>
	</li><li>
		<a href="'.site_url('jabatan_fungsional_batas_usia').'"><i class="fa fa-list fa-fw"></i> Jabatan fungsional batas usia</a>
	</li><li>
		<a href="'.site_url('jabatan_fungsional_jenjang').'"><i class="fa fa-list fa-fw"></i> Jabatan fungsional jenjang</a>
	</li><li>
		<a href="'.site_url('jabatan_fungsional_jenjang_golongan_kredit').'"><i class="fa fa-list fa-fw"></i> Jabatan fungsional jenjang golongan kredit</a>
	</li><li>
		<a href="'.site_url('jabatan_fungsional_jenjang_tingkat').'"><i class="fa fa-list fa-fw"></i> Jabatan fungsional jenjang tingkat</a>
	</li><li>
		<a href="'.site_url('jabatan_fungsional_judul').'"><i class="fa fa-list fa-fw"></i> Jabatan fungsional judul</a>
	</li><li>
		<a href="'.site_url('jabatan_fungsional_kategori').'"><i class="fa fa-list fa-fw"></i> Jabatan fungsional kategori</a>
	</li><li>
		<a href="'.site_url('jabatan_fungsional_kategori_jabatan').'"><i class="fa fa-list fa-fw"></i> Jabatan fungsional kategori jabatan</a>
	</li><li>
		<a href="'.site_url('jabatan_fungsional_kelompok').'"><i class="fa fa-list fa-fw"></i> Jabatan fungsional kelompok</a>
	</li><li>
		<a href="'.site_url('jabatan_fungsional_syarat_jenjang').'"><i class="fa fa-list fa-fw"></i> Jabatan fungsional syarat jenjang</a>
	</li><li>
		<a href="'.site_url('jabatan_fungsional_syarat_kelompok').'"><i class="fa fa-list fa-fw"></i> Jabatan fungsional syarat kelompok</a>
	</li><li>
		<a href="'.site_url('jabatan_fungsional_syarat_pengangkatan').'"><i class="fa fa-list fa-fw"></i> Jabatan fungsional syarat pengangkatan</a>
	</li><li>
		<a href="'.site_url('jabatan_fungsional_tingkat').'"><i class="fa fa-list fa-fw"></i> Jabatan fungsional tingkat</a>
	</li><li>
		<a href="'.site_url('jabatan_fungsional_tingkat_jabatan').'"><i class="fa fa-list fa-fw"></i> Jabatan fungsional tingkat jabatan</a>
	</li><li>
		<a href="'.site_url('jabatan_fungsional_tunjangan').'"><i class="fa fa-list fa-fw"></i> Jabatan fungsional tunjangan</a>
	</li><li>
		<a href="'.site_url('jabatan_jenjang_kategori').'"><i class="fa fa-list fa-fw"></i> Jabatan jenjang kategori</a>
	</li><li>
		<a href="'.site_url('jabatan_kode_pengangkatan').'"><i class="fa fa-list fa-fw"></i> Jabatan kode pengangkatan</a>
	</li><li>
		<a href="'.site_url('jabatan_kode_syarat').'"><i class="fa fa-list fa-fw"></i> Jabatan kode syarat</a>
	</li><li>
		<a href="'.site_url('jabatan_level').'"><i class="fa fa-list fa-fw"></i> Jabatan level</a>
	</li><li>
		<a href="'.site_url('jabatan_level_opd').'"><i class="fa fa-list fa-fw"></i> Jabatan level opd</a>
	</li><li>
		<a href="'.site_url('jabatan_opd').'"><i class="fa fa-list fa-fw"></i> Jabatan opd</a>
	</li><li>
		<a href="'.site_url('jabatan_pelaksana').'"><i class="fa fa-list fa-fw"></i> Jabatan pelaksana</a>
	</li><li>
		<a href="'.site_url('jabatan_pelaksana_kelompok').'"><i class="fa fa-list fa-fw"></i> Jabatan pelaksana kelompok</a>
	</li><li>
		<a href="'.site_url('jabatan_pelaksana_kualifikasi').'"><i class="fa fa-list fa-fw"></i> Jabatan pelaksana kualifikasi</a>
	</li><li>
		<a href="'.site_url('jabatan_pelaksana_urusan').'"><i class="fa fa-list fa-fw"></i> Jabatan pelaksana urusan</a>
	</li><li>
		<a href="'.site_url('jabatan_rumpunpelaksana').'"><i class="fa fa-list fa-fw"></i> Jabatan rumpunpelaksana</a>
	</li><li>
		<a href="'.site_url('jabatan_syarat_jurusans').'"><i class="fa fa-list fa-fw"></i> Jabatan syarat jurusans</a>
	</li><li>
		<a href="'.site_url('jabatan_syarat_pendidikan_jft').'"><i class="fa fa-list fa-fw"></i> Jabatan syarat pendidikan jft</a>
	</li><li>
		<a href="'.site_url('jabatan_syarat_pendidikans').'"><i class="fa fa-list fa-fw"></i> Jabatan syarat pendidikans</a>
	</li><li>
		<a href="'.site_url('jabatans').'"><i class="fa fa-list fa-fw"></i> Jabatans</a>
	</li><li>
		<a href="'.site_url('jenis_opd').'"><i class="fa fa-list fa-fw"></i> Jenis opd</a>
	</li><li>
		<a href="'.site_url('jenjang').'"><i class="fa fa-list fa-fw"></i> Jenjang</a>
	</li><li>
		<a href="'.site_url('jenjang_kategori').'"><i class="fa fa-list fa-fw"></i> Jenjang kategori</a>
	</li><li>
		<a href="'.site_url('jenjang_kategori_golongan').'"><i class="fa fa-list fa-fw"></i> Jenjang kategori golongan</a>
	</li><li>
		<a href="'.site_url('jenjang_kategori_jf_tertentu').'"><i class="fa fa-list fa-fw"></i> Jenjang kategori jf tertentu</a>
	</li><li>
		<a href="'.site_url('jpendidikans').'"><i class="fa fa-list fa-fw"></i> Jpendidikans</a>
	</li><li>
		<a href="'.site_url('jurusan_bidang').'"><i class="fa fa-list fa-fw"></i> Jurusan bidang</a>
	</li><li>
		<a href="'.site_url('jurusans').'"><i class="fa fa-list fa-fw"></i> Jurusans</a>
	</li><li>
		<a href="'.site_url('kelas').'"><i class="fa fa-list fa-fw"></i> Kelas</a>
	</li><li>
		<a href="'.site_url('migrations').'"><i class="fa fa-list fa-fw"></i> Migrations</a>
	</li><li>
		<a href="'.site_url('opds').'"><i class="fa fa-list fa-fw"></i> Opds</a>
	</li><li>
		<a href="'.site_url('pangkats').'"><i class="fa fa-list fa-fw"></i> Pangkats</a>
	</li><li>
		<a href="'.site_url('password_resets').'"><i class="fa fa-list fa-fw"></i> Password resets</a>
	</li><li>
		<a href="'.site_url('pegawai_pendidikans').'"><i class="fa fa-list fa-fw"></i> Pegawai pendidikans</a>
	</li><li>
		<a href="'.site_url('pegawais').'"><i class="fa fa-list fa-fw"></i> Pegawais</a>
	</li><li>
		<a href="'.site_url('pendidikan_pangkats').'"><i class="fa fa-list fa-fw"></i> Pendidikan pangkats</a>
	</li><li>
		<a href="'.site_url('pma__bookmark').'"><i class="fa fa-list fa-fw"></i> Pma  bookmark</a>
	</li><li>
		<a href="'.site_url('pma__central_columns').'"><i class="fa fa-list fa-fw"></i> Pma  central columns</a>
	</li><li>
		<a href="'.site_url('pma__column_info').'"><i class="fa fa-list fa-fw"></i> Pma  column info</a>
	</li><li>
		<a href="'.site_url('pma__designer_settings').'"><i class="fa fa-list fa-fw"></i> Pma  designer settings</a>
	</li><li>
		<a href="'.site_url('pma__export_templates').'"><i class="fa fa-list fa-fw"></i> Pma  export templates</a>
	</li><li>
		<a href="'.site_url('pma__favorite').'"><i class="fa fa-list fa-fw"></i> Pma  favorite</a>
	</li><li>
		<a href="'.site_url('pma__history').'"><i class="fa fa-list fa-fw"></i> Pma  history</a>
	</li><li>
		<a href="'.site_url('pma__navigationhiding').'"><i class="fa fa-list fa-fw"></i> Pma  navigationhiding</a>
	</li><li>
		<a href="'.site_url('pma__pdf_pages').'"><i class="fa fa-list fa-fw"></i> Pma  pdf pages</a>
	</li><li>
		<a href="'.site_url('pma__recent').'"><i class="fa fa-list fa-fw"></i> Pma  recent</a>
	</li><li>
		<a href="'.site_url('pma__relation').'"><i class="fa fa-list fa-fw"></i> Pma  relation</a>
	</li><li>
		<a href="'.site_url('pma__savedsearches').'"><i class="fa fa-list fa-fw"></i> Pma  savedsearches</a>
	</li><li>
		<a href="'.site_url('pma__table_coords').'"><i class="fa fa-list fa-fw"></i> Pma  table coords</a>
	</li><li>
		<a href="'.site_url('pma__table_info').'"><i class="fa fa-list fa-fw"></i> Pma  table info</a>
	</li><li>
		<a href="'.site_url('pma__table_uiprefs').'"><i class="fa fa-list fa-fw"></i> Pma  table uiprefs</a>
	</li><li>
		<a href="'.site_url('pma__tracking').'"><i class="fa fa-list fa-fw"></i> Pma  tracking</a>
	</li><li>
		<a href="'.site_url('pma__userconfig').'"><i class="fa fa-list fa-fw"></i> Pma  userconfig</a>
	</li><li>
		<a href="'.site_url('pma__usergroups').'"><i class="fa fa-list fa-fw"></i> Pma  usergroups</a>
	</li><li>
		<a href="'.site_url('pma__users').'"><i class="fa fa-list fa-fw"></i> Pma  users</a>
	</li><li>
		<a href="'.site_url('ruangs').'"><i class="fa fa-list fa-fw"></i> Ruangs</a>
	</li><li>
		<a href="'.site_url('rumpun_jabatan').'"><i class="fa fa-list fa-fw"></i> Rumpun jabatan</a>
	</li><li>
		<a href="'.site_url('urusan').'"><i class="fa fa-list fa-fw"></i> Urusan</a>
	</li><li>
		<a href="'.site_url('users').'"><i class="fa fa-list fa-fw"></i> Users</a>
	</li>';
	}
	function cmb_dinamis($name, $table, $field, $pk, $selected = null, $extra = null) {
		$ci = & get_instance();
		$cmb = "<select name='$name'  id='$name' class='selectpicker form-control' $extra data-live-search='true'>";
		$cmb .="<option value='0' >--Pilih--</option>";
		$data = $ci->db->get($table)->result();
		foreach ($data as $row) {
			$cmb .="<option value='" . $row->$pk . "' data-tokens='" . $row->$field . "'";
			$cmb .= $selected == $row->$pk ? 'selected' : '';
			$cmb .=">" . $row->$field . "</option>";
		}
		$cmb .= "</select>";
		return $cmb;
	}
	